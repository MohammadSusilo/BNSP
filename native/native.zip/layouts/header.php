<!doctype html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <meta name="description" content="">
        <meta name="author" content="">

        <title>Talk Scholarship</title>

        <?php include('layouts/css.php'); ?>     
    </head>
    
    <body id="top">
        <main>
            <?php include('layouts/navbar.php'); ?>