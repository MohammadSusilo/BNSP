        <!-- CSS FILES -->        
        <link rel="preconnect" href="https://fonts.googleapis.com">
        
        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>

        <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@500;600;700&family=Open+Sans&display=swap" rel="stylesheet">
                        
        <link href="assets/frontend/css/bootstrap.min.css" rel="stylesheet">

        <link href="assets/frontend/css/bootstrap-icons.css" rel="stylesheet">

        <link href="assets/frontend/css/templatemo-topic-listing.css" rel="stylesheet">   