        <!-- JAVASCRIPT FILES -->
        <script src="assets/frontend/js/jquery.min.js"></script>
        <script src="assets/frontend/js/bootstrap.bundle.min.js"></script>
        <script src="assets/frontend/js/jquery.sticky.js"></script>
        <script src="assets/frontend/js/click-scroll.js"></script>
        <script src="assets/frontend/js/custom.js"></script>