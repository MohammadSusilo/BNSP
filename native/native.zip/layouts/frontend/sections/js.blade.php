        <!-- JAVASCRIPT FILES -->
        <script src="{{ asset('frontend/js/jquery.min.js') }}"></script>
        <script src="{{ asset('frontend/js/bootstrap.bundle.min.js') }}"></script>
        <script src="{{ asset('frontend/js/jquery.sticky.js') }}"></script>
        <script src="{{ asset('frontend/js/click-scroll.js') }}"></script>
        <script src="{{ asset('frontend/js/custom.js') }}"></script>